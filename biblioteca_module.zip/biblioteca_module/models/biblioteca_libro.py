# models/biblioteca_libro.py
from odoo import models, fields

class BibliotecaLibro(models.Model):
    _name = 'biblioteca.libro'
    _description = 'Libro de la biblioteca'
    
    # Campos
    nombre = fields.Char(string='Título', required=True)
    autor = fields.Char(string='Autor', required=True)
    fecha_publicacion = fields.Date(string='Fecha de Publicación')
    categoria = fields.Char(string='Categoría')
    estado = fields.Selection([
        ('disponible', 'Disponible'),
        ('prestado', 'Prestado'),
        ('reservado', 'Reservado')
    ], string='Estado', default='disponible')
    descripcion = fields.Text(string='Descripción')
    codigo = fields.Char(string='Código del Libro')
    
    # Relación con el modelo de usuario para registrar quién tiene el libro prestado
    prestado_a = fields.Many2one('res.users', string='Prestado a')
