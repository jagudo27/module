# biblioteca_module/models/__init__.py

from . import biblioteca_libro
