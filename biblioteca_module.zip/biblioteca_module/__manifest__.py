{
    'name': 'Gestión de Biblioteca',
    'summary': 'Gestión de libros en una biblioteca',
    'version': '1.0',
    'category': 'Herramientas',
    'description': """
Un módulo simple para gestionar los libros de una biblioteca, permitiendo
registrar títulos, autores, fechas de publicación, categorías, estados,
y usuarios que los tengan prestados.
""",
    'author': 'Izan Gómez',
    'license': 'LGPL-3',
    'depends': ['base'],
    'data': [
        'views/biblioteca_libro_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
