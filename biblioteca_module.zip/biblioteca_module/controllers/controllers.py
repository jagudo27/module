# -*- coding: utf-8 -*-
# from odoo import http


# class BibliotecaModule(http.Controller):
#     @http.route('/biblioteca_module/biblioteca_module', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/biblioteca_module/biblioteca_module/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('biblioteca_module.listing', {
#             'root': '/biblioteca_module/biblioteca_module',
#             'objects': http.request.env['biblioteca_module.biblioteca_module'].search([]),
#         })

#     @http.route('/biblioteca_module/biblioteca_module/objects/<model("biblioteca_module.biblioteca_module"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('biblioteca_module.object', {
#             'object': obj
#         })

